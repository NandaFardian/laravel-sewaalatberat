<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LaporanSewa extends Model
{
    // use HasFactory;
    // public function transaksis(){
    //     return $this->hasOne(Transaksi::class,'id','transaksis_id');
    // }
        // use HasFactory;
        // public function merks(){
        //     return $this->hasOne(Merk::class,'id','merks_id');
        // }
        // public function alatberats(){
        //     return $this->hasOne(Alatberat::class,'id','alatberats_id');
        // }
        // public function laporansewas(){
        //     return $this->belongTo(LaporanSewa::class);
        // }
}
