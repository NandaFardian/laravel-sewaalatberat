<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/media/image/favicon.png')); ?>"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bundle.css')); ?>" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.min.css')); ?>" type="text/css">
</head>
<body class="form-membership">

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->

<div class="form-wrapper">


    
    <h5>Login</h5>

    <!-- form -->
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="text" name="email" class="form-control" placeholder="Username or email" required autofocus>
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="form-group d-flex justify-content-between">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" name="remember" class="custom-control-input" checked="" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Ingat saya</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Masuk</button>
        <hr>
        <p class="text-muted">Belum Punya Akun?</p>
        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light btn-sm">Daftar Sekarang</a>
    </form>
    <!-- ./ form -->


</div>

<!-- Plugin scripts -->
<script src="<?php echo e(asset('vendors/bundle.js')); ?>"></script>

<!-- App scripts -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/auth/login.blade.php ENDPATH**/ ?>