
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<?php $__env->startSection('content'); ?>
<div class="content ">
                
    <div class="page-header">
        <div>
            <h3>Data Pelanggan</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Data Master</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Data Pelanggan</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table">
            
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Pelanggan</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">No Hp</th>
                  </tr>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>   
                            <?php if($item->level==null): ?>  
                            <th scope="row"><?php echo e($nomor++); ?></th>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->alamat); ?></td>
                            <td><?php echo e($item->no_hp); ?></td>
                            <?php else: ?>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="table-primary">
                            <td colspan="6">Tidak Ada Data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
</div>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/pelanggan/index.blade.php ENDPATH**/ ?>