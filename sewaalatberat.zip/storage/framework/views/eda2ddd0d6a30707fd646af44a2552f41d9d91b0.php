<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CETAK DATA SEWA</title>
</head>
<body>
    <div class="form-group">
    <p align="center"><b>Laporan Data Sewa</b></p>
    <table class="static" align="center" rules="all" border="1px" style="width: 95%">
        <tr>
            <th>No</th>
            <th>Nama Penyewa</th>
            <th>Alamat</th>
            <th>No Hp</th>
            <th>Jenis Alat Berat</th>
            <th>Tanggal Sewa</th>
            <th>Harga</th>
            <th>Biaya Operator</th>
            <th>Pajak</th>
            <th>Total Biaya</th>
        </tr>
        <?php $__currentLoopData = $cetakpdf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->nama_pen); ?></td>
                <td><?php echo e($item->alamat); ?></td>
                <td><?php echo e($item->no_hp); ?></td>
                <td><?php echo e($item->alatberats->nm_alat); ?></td>
                <td><?php echo e($item->tanggal_sewa); ?></td>
                <td>Rp. <?php echo e(format_numberic ($item->alatberats->harga)); ?></td>
                <td>Rp. <?php echo e($item->biaya_ope); ?></td>
                <td>Rp. <?php echo e($item->pajak); ?></td>
                <td>Rp. <?php echo e($item->total_biaya); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
    <script type="text/javascript">
        window.print();
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/laporan_sewa/pdf.blade.php ENDPATH**/ ?>