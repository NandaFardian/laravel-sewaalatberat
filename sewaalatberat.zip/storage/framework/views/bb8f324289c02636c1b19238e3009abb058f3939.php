
<?php $__env->startSection('content'); ?>
    <div class="page-title-area pt-200 pb-200 " style="background-image: url(assets2/img/bg/banner.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="page-titel-detalis  ">
                        <div align="center">
                            <?php if(auth()->guard()->check()): ?>
                            <h1 style="color: white">SELAMAT DATANG, <?php echo e(Auth::user()->name); ?></h1>
                            <h1 style="color: white">DI</h1>
                            <h1 style="color: white">PENYEWAAN ALAT test</h1>
                            <?php else: ?>
                            <h1 style="color: white">SELAMAT DATANG</h1>
                            <h1 style="color: white">DI</h1>
                            <h1 style="color: white">PENYEWAAN ALAT BERAT</h1>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/beranda/index.blade.php ENDPATH**/ ?>