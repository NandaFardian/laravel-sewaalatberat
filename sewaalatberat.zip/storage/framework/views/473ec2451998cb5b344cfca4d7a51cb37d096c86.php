<?php $__env->startSection('title','Sistem Informasi Penyewaan Alat Berat'); ?>
<?php $__env->startSection('content'); ?>
    

    <!-- Custom styles for this template-->
    
    <div class="content ">
        <div class="page-header d-md-flex justify-content-between">
        <div>
            <h2>Dashboard</h2>
            
        </div>
        
    </div>
    
    <div class="row">
        
        <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Alat Berat</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-primary-bright text-primary rounded-pill">
                                            <i class="ti-truck"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_alatberat); ?></div>
                            </div>
                            <a href="/alatberat">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
                
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Operator</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-info-bright text-info rounded-pill">
                                            <i class="ti-id-badge"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_operator); ?></div>
                            </div>
                            <a href="/ope">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            
                
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Pelanggan</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-secondary-bright text-secondary rounded-pill">
                                            <i class="ti-user"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_pelanggan); ?></div>
                            </div>
                            <a href="/pelanggan">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            
                
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Merk</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-warning-bright text-warning rounded-pill">
                                            <i class="ti-menu-alt"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_merk); ?></div>
                            </div>
                            <a href="/merk">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            
                
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Sewa</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-warning-bright text-warning rounded-pill">
                                            <i class="ti-clipboard"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_sewa); ?></div>
                            </div>
                            <a href="/sewa">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            
                
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Bayar</h6>
                            <div class="d-flex align-items-center mb-3">
                                <div>
                                    <div class="avatar">
                                        <span class="avatar-title bg-danger-bright text-danger rounded-pill">
                                            <i class="ti-money"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_sewa); ?></div>
                            </div>
                            <a href="/pembayaran">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Belum Bayar</h6>
                    <div class="d-flex align-items-center mb-3">
                        <div>
                            <div class="avatar">
                                <span class="avatar-title bg-primary-bright text-success rounded-pill">
                                    <i class="ti-stats-down"></i>
                                </span>
                            </div>
                        </div>
                        <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_belumbayar); ?></div>
                    </div>
                    <a href="/pembayaran">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                </div>
            </div>
        
</div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Sudah Bayar</h6>
                    <div class="d-flex align-items-center mb-3">
                        <div>
                            <div class="avatar">
                                <span class="avatar-title bg-primary-bright text-primary rounded-pill">
                                    <i class="ti-stats-up"></i>
                                </span>
                            </div>
                        </div>
                        <div class="font-weight-bold ml-1 font-size-30 ml-3"><?php echo e($jumlah_sudahbayar); ?></div>
                    </div>
                    <a href="/pembayaran">Info Lebih Lanjut<i class="ti-arrow-right"></i></a>
                </div>
            </div>
        
</div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/home.blade.php ENDPATH**/ ?>