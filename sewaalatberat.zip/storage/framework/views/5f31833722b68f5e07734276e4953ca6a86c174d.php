<?php $__env->startSection('content'); ?>
    
    <div class="content-wrapper">
        <!-- begin::navigation -->
        <div class="navigation">
            <div class="navigation-header">
                <span>Navigation</span>
                <a href="#">
                    <i class="ti-close"></i>
                </a>
            </div>
            <div class="navigation-menu-body">
                <ul>
                    <li>
                        <a  class="active"  href=index.php>
                    <span class="nav-link-icon">
                        <i data-feather="pie-chart"></i>
                    </span>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                    <span class="nav-link-icon">
                    <i data-feather="layers"></i>
                    </span>
                            <span>Data Master</span>
                        </a>
                        <ul>
                            <li>
                                <a  href="/pelanggan">Data Pelangan</a>
                            </li>
                            <li>
                                <a  href="/alatberat">Data Alat Berat</a>
                            </li>
                            <li>
                                <a  href="/merk">Data Merk</a>
                            </li>
                            <li>
                                <a  href="/operator">Data Operator</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">
                    <span class="nav-link-icon">
                        <i data-feather="edit-3"></i>
                    </span>
                            <span>Forms</span>
                        </a>
                        <ul>
                            <li>
                                <a  href="form_tambah_pel.php">Form Tambah Pelanggan</a>
                            </li>
                            <li>
                                <a  href="form_tambah.php">Form Tambah Alat Berat</a>
                            </li>
                            <li>
                                <a  href="formmerk_tambah.php">Form Tambah Merk</a>
                            </li>
                            <li>
                                <a  href="form_tambah_ope.php">Form Tambah Operator</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">
                    <span class="nav-link-icon">
                        <i data-feather="edit-3"></i>
                    </span>
                            <span>Laporan</span>
                        </a>
                        <ul>
                            <li>
                                <a  href="#">Laporan Alat Berat</a>
                            </li>
                            <li>
                                <a  href="#">Laporan Transaksi</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <!-- end::navigation -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/index.blade.php ENDPATH**/ ?>