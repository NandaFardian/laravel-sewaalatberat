
<?php $__env->startSection('content'); ?>
<div class="product-area pt-50 ">
    <div class="container">
        <div class="row justify-content-center">
    <?php $__currentLoopData = $sewa->sewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->status == 0): ?>
        <div class="col d-flex" class="elementor-image-box-img">
        <div class="card-header">
        <div style="width: 18rem;">
            <p>Kode Sewa : <?php echo e($item->kd_sewa); ?></p>
            <p>Nama : <?php echo e($item->nama_pen); ?></p>
            <p>Total Biaya : Rp. <?php echo e($item->total_biaya); ?></p>
            <h5><?php echo e($item->nm_alat); ?> </h5>
            <a href="/bayarsewa/<?php echo e($item->id); ?>" class="btn btn-success">Bayar</a>
        <?php else: ?>
        <?php endif; ?>
        
    </div>
    <div>
    </div>
    <div>

    </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/bayar.blade.php ENDPATH**/ ?>