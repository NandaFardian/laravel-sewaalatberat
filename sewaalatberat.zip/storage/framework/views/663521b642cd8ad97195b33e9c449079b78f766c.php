
<?php $__env->startSection('title','Data Alat Berat'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<?php $__env->startSection('content'); ?>
<div class="content ">        
                
    <div class="page-header">
        <div>
            <h3>Data Alat Berat</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Data Master</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Data Alat Berat</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
          <a href="/alatberat/form" class="float-start btn btn-success">Tambah Data</a>
          <form action="/alatberat" method="GET" class="float-right">

              <div class="input-group input-group-sm float-right" style="width: 150px;">
                <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo e($request->search); ?>">
                <button type="submit" class="btn btn-default">
                  <i class="fa fa-search"></i>
                </button>
              </div>
            
          </form>
        </div>
        <div class="card-body">
            <table class="table">
                
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Jenis Alat Berat</th>
                    <th scope="col">Merk</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Aksi</th>
                  </tr>
              
                <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $alatberat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>     
                            <th scope="row"><?php echo e($nomor++); ?></th>
                            <td><?php echo e($item->nm_alat); ?></td>
                            <td><?php echo e($item->merks->merk); ?></td>
                            <td><?php echo e($item->jumlah); ?></td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm"   data-bs-toggle="modal" data-bs-target="#exampleModal1<?php echo e($item->id); ?>">
                                  Detail
                                </button>
                              
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal1<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Detail</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <div class="modal-body text-center">
                                        <img src="berkas/<?php echo e($item->foto); ?>" height="350" alt="">
                                      </div>
                                      <div class=" text-center">
                                        <p>Jenis Alat Berat : <b><?php echo e($item->nm_alat); ?></b></p>
                                        <p>Merk : <b><?php echo e($item->merks->merk); ?></b></p>
                                        <p>Tahun : <b><?php echo e($item->tahun); ?></b></p>
                                        <p>Jumlah : <b><?php echo e($item->jumlah); ?></b></p>
                                        <p>Harga : <b>Rp. <?php echo e($item->harga); ?></b></p>
                                      </div>
                                      
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Tutup</button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <a href="/alatberat/edit/<?php echo e($item->id); ?>" class="btn btn-warning fa fa-pencil btn-sm"></a>
                                <button type="button" class="btn btn-danger btn-sm fa fa-trash" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item->id); ?>">
                                 
                                </button>
                                <div class="modal fade" id="exampleModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Peringatan</h5>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                          Yakin <b><?php echo e($item->nm_alat); ?></b> ingin di hapus?
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <form method="post" action="/alatberat/<?php echo e($item->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-primary">Hapus</button>
                                            </form>
                                        </div>
                                      </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="table-primary">
                            <td colspan="6">Tidak Ada Data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
</div>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/alatberat/index.blade.php ENDPATH**/ ?>