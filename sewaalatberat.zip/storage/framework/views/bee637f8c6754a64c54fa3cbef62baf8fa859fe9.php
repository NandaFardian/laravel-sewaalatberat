
<?php $__env->startSection('content'); ?>
<div class ="container mt-3 bg-white p-4">
    <div class="card">
        <div class="card-header">
          <h4 class="float-start">Form Edit Data Pelanggan</h4>
        </div>
        <div class="card-body">
            <form method="post" action="/pelanggan/<?php echo e($pel->id); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Nama Pelanggan</label>
                  <input type="text" value="<?php echo e($pel->nama); ?>" name="nama" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">Alamat</label>
                  <input type="text" value="<?php echo e($pel->alamat); ?>" name="alamat" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">No Hp</label>
                  <input type="text" value="<?php echo e($pel->no_hp); ?>" name="no_hp" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" class="btn btn-primary">Tambah Data</button>
                <a href="/pelanggan" class="btn btn-warning text-white">Batal</a>
              </form>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/pelanggan/edit.blade.php ENDPATH**/ ?>