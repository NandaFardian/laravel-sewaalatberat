
<?php $__env->startSection('content'); ?>
<div class="content ">
    <div class="page-header">
        
    </div>
    <div class="card">
    <div class="card-header">
      <h4 class="float-start">Form Tambah Transaksi</h4>
    </div>
    <div class="card-body">
        <form method="post" action="/transaksi/store">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Kode</label>
              <input type="text" name="kode" readonly class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($nomer); ?>">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Nama Penyewa</label>
              <input type="text" name="nama"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Alamat Lengkap</label>
              <input type="text" name="alamat"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">No Hp</label>
              <input type="text" name="nohp"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Jenis Alat Berat</label>
              <select name="alatberat" id="" class="form-control">
                <option value="">-Pilih alat Berat-</option>
                <?php $__currentLoopData = $alatberat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nm_alat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Tanggal Sewa</label>
              <input type="date" name="tgl_sewa"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Tanggal Kembali</label>
              <input type="date" name="tgl_kem"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">               
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Harga</label>
              <input type="text" name="harga"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Biaya Operator</label>
              <input type="text" name="biaya_ope" value=100000  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Pajak</label>
              <input type="text" name="pajak" value=25% class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Total Biaya</label>
              <input type="text" name="total" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Status</label>
              <input type="text" name="status" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <button type="submit" class="btn btn-primary">Tambah Data</button>
            <a href="/alatberat" class="btn btn-warning text-white">Batal</a>
          </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/transaksi/form.blade.php ENDPATH**/ ?>