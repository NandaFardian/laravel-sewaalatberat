
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<?php $__env->startSection('content'); ?>

<div class="content ">
                
    <div class="page-header">
        <div>
            <h3>Laporan Penyewaan</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Data Master</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Laporan Sewa</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <form action="post" action="/laporan_sewa">
            <table class="table table-striped">
                <tr>
                    <td>
                        <input type="date" value="<?= date('Y-m-d');?>" class="form-control" name="hari">
                    </td>
                    
                    <td>
                            <button class="btn btn-primary">
                                <i class="fa fa-search"></i> Cari
                            </button>
                            <a href="/laporan_sewa" class="btn btn-success">
                                <i class="fa fa-refresh"></i> Refresh</a>
                                
                            <?php if(!empty($_GET['cari'])){?>
                                <a href="excel.php?cari=yes&bln=<?=$_POST['bln'];?>&thn=<?=$_POST['thn'];?>" class="btn btn-info"><i class="fa fa-download"></i>
                                Excel</a>
                            <?php }else{?>
                                <a href="/laporan_sewa/pdf" target="_blank" class="btn btn-success">PDF</a>
                            <?php }?>
                    </td>
                </tr>
            </table>
            </form>
        <div class="card">  
            <table class="table">
                
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kode Sewa</th>
                    <th scope="col">Nama Penyewa</th>
                    <th scope="col">Alamat Lengkap</th>
                    <th scope="col">Tanggal Sewa</th>
                    <th scope="col">Jenis Alat Berat</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Biaya Operator</th>
                    <th scope="col">Pajak</th>
                    <th scope="col">Total Biaya</th>
                  </tr>
                
                <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $sewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>     
                            <th scope="row"><?php echo e($nomor++); ?></th>
                            <td><?php echo e($item->kd_sewa); ?></td>
                            <td><?php echo e($item->nama_pen); ?></td>
                            <td><?php echo e($item->alamat); ?></td>
                            <td><?php echo e($item->tanggal_sewa); ?></td>
                            <td><?php echo e($item->alatberats->nm_alat); ?></td>
                            <td>Rp. <?php echo e($item->alatberats->harga); ?></td>
                            <td>Rp. <?php echo e($item->biaya_ope); ?></td>
                            <td><?php echo e($item->pajak); ?></td>
                            <td>Rp. <?php echo e($item->total_biaya); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="table-primary">
                            <td colspan="14">Tidak Ada Data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
</div>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/laporan_sewa/index.blade.php ENDPATH**/ ?>