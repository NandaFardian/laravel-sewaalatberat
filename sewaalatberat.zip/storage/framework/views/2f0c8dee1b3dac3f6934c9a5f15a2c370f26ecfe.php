
<?php $__env->startSection('content'); ?>
<div class="product-area pt-50 ">
    <div class="container">
        <div class="row justify-content-center">
    <?php $__currentLoopData = $sewa->sewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col d-flex" class="elementor-image-box-img">
    <div class="card-header">
        <div style="width: 18rem;">
            <img src="berkas/<?php echo e($item->alatberats->foto); ?>" height="150" alt="">
        <p>Jenis Alat Berat : <?php echo e($item->alatberats->nm_alat); ?></p>
        <p>Tanggal Sewa : <?php echo e($item->tanggal_sewa); ?></p>
        <p>Total Biaya : Rp. <?php echo e(number_format ($item->total_biaya)); ?></p>
        <h5><?php echo e($item->nm_alat); ?> </h5>
    </div>
    <div>
    </div>
    <div>

    </div>
    </div>
    </div>
  

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sewaalatberat\resources\views/page/riwayat/index.blade.php ENDPATH**/ ?>